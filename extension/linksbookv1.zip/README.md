# RGB-to-hex-converter

A web app that converts RGB to Hex color codes

## How to install

clone the repository.
Open `chrome://extensions/` and activate developer mode.
Click on ´Load Unpacked´ and navigate to where teh folder containing the cloned repository is found.
Select the folder and click `select folder`.
The extension will be added to chrome and _VOILA!_.
You can now use it

Fun!
